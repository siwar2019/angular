import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Todo } from '../models/Todo';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private _addTodoUrl = "http://localhost:3000/todo/addTodo";

  constructor(private http: HttpClient) { }

  addTodo(todo) {
    return this.http.post<any>(this._addTodoUrl,todo);
  }

  listTodo(iduser){
    return this.http.post<any>(`http://localhost:3000/todo/todoList/`+iduser,"");

  }

  updateTodo(id)
  {
    return this.http.patch<any>(`http://localhost:3000/todo/updateTodo/`+id,"")
  }

}

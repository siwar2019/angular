import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { UserService } from '../services/user.service';
import { TodoService } from '../services/todo.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-todo',
  templateUrl: './update-todo.component.html',
  styleUrls: ['./update-todo.component.css']
})
export class UpdateTodoComponent implements OnInit {

  form: FormGroup;

  constructor(fb: FormBuilder, private _userService:UserService , private _todoService: TodoService, private router: Router) {
    this.form = fb.group({
      description: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
      ])
    }
    )
  }

  get description() { return this.form.get('description'); }


  ngOnInit() {
  }

}
